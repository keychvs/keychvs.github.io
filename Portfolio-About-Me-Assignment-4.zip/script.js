
let name = document.getElementById("state");
let newName = prompt("What state are you from?");

let age = document.getElementById("age");
let newage = prompt("How old are you?");

name.innerHTML = state;

var button = document.getElementById ("btn");
button.addEventListener (click, function () {
  alert ("Click to to move to the next page")
});
